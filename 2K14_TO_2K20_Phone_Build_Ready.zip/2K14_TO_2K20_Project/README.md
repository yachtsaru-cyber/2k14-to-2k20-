# 2K14 TO 2K20 (Android starter project)

Native Android Java project. It has a working converter UI and reads verified mappings from `app/src/main/assets/cfid_map.csv`.


## Important
The mapping CSV is intentionally empty until verified CFID pairs are supplied. The app does not invent IDs.

## Build
Open this folder in Android Studio, allow Gradle sync, then use Build > Build APK(s). Requires Android Studio/SDK and network access for initial Gradle setup.

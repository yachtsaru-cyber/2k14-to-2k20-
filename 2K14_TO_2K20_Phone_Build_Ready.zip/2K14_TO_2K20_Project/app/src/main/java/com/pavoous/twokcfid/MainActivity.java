package com.pavoous.twokcfid;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private final Map<String, String> mapping = new HashMap<>();
    private EditText input;
    private TextView result;
    private final int bg = Color.rgb(16,21,29), panel = Color.rgb(26,34,45), teal = Color.rgb(72,214,197), white = Color.WHITE, muted = Color.rgb(160,175,190);
    @Override public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); loadMappings(); buildUI(); }
    private void loadMappings() {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(getAssets().open("cfid_map.csv")))) {
            String line; while ((line=br.readLine())!=null) { if(line.trim().isEmpty() || line.startsWith("#")) continue; String[] p=line.split(",",3); if(p.length>=2) mapping.put(p[0].trim(),p[1].trim()); }
        } catch(Exception ignored) {}
    }
    private TextView text(String s, int size, int color, boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private void buildUI() {
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,28,24,24); root.setGravity(Gravity.CENTER_HORIZONTAL); scroll.addView(root); setContentView(scroll);
        TextView brand=text("2K14 TO 2K20",26,teal,true); brand.setGravity(Gravity.CENTER); root.addView(brand);
        TextView subtitle=text("CFID CONVERTER  •  OFFLINE",12,muted,true); subtitle.setGravity(Gravity.CENTER); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-2,-2); sp.topMargin=8; root.addView(subtitle,sp);
        TextView info=text("Convert player IDs using a verified mapping database.",14,muted,false); info.setGravity(Gravity.CENTER); sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=24; root.addView(info,sp);
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(18,18,18,18); card.setBackgroundColor(panel); sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=22; root.addView(card,sp);
        TextView label=text("NBA 2K14 CFID",14,white,true); card.addView(label);
        input=new EditText(this); input.setSingleLine(true); input.setHint("Enter CFID"); input.setHintTextColor(muted); input.setTextColor(white); input.setInputType(2); input.setPadding(12,10,12,10); input.setBackgroundColor(Color.rgb(35,45,57)); sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=10; card.addView(input,sp);
        Button convert=new Button(this); convert.setText("CONVERT TO 2K20"); convert.setTextColor(bg); convert.setBackgroundTintList(android.content.res.ColorStateList.valueOf(teal)); sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=14; card.addView(convert,sp);
        result=text("Converted CFID will appear here",18,white,true); result.setGravity(Gravity.CENTER); result.setPadding(12,24,12,24); result.setBackgroundColor(Color.rgb(35,45,57)); sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=16; card.addView(result,sp);
        Button copy=new Button(this); copy.setText("COPY RESULT"); copy.setTextColor(white); copy.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(50,65,80))); sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=8; card.addView(copy,sp);
        TextView status=text("Mapping entries loaded: "+mapping.size(),12,muted,false); status.setGravity(Gravity.CENTER); sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=18; root.addView(status,sp);
        TextView note=text("No guessed IDs: conversion works only for IDs present in the mapping file.",12,muted,false); note.setGravity(Gravity.CENTER); sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=12; root.addView(note,sp);
        convert.setOnClickListener(v->{String id=input.getText().toString().trim(); if(id.isEmpty()){result.setText("Enter a CFID first.");return;} String out=mapping.get(id); result.setText(out==null?"No verified match for CFID "+id:out);});
        copy.setOnClickListener(v->{String out=result.getText().toString(); if(mapping.containsKey(input.getText().toString().trim())) { ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("CFID",out)); Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show(); } else Toast.makeText(this,"No converted ID to copy",Toast.LENGTH_SHORT).show(); });
    }
}
